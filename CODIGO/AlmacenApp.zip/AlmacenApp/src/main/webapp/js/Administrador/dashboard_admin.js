/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/JavaScript.js to edit this template
 */


// Mostrar/ocultar el menú en pantallas pequeñas
function toggleMenu() {
    const menu = document.getElementById("menu");
    menu.classList.toggle("show");
}
