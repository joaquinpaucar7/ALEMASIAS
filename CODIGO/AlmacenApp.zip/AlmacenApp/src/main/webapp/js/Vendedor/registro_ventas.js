/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/JavaScript.js to edit this template
 */


// Modal
let modal = document.getElementById("modal");
let btn = document.getElementById("nuevoVentaBtn");
let span = document.getElementById("closeBtn");

// Abrir el modal
btn.onclick = function() {
    modal.style.display = "block";
}

// Cerrar el modal
span.onclick = function() {
    modal.style.display = "none";
}

// Cerrar el modal si se hace clic fuera de él
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
