/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.almacen.dao;

import com.almacen.model.Venta;
import com.almacen.utils.ConexionDB;
import java.sql.*;

public class VentaDAO {

    // Método para agregar una nueva venta
    public void agregarVenta(Venta venta) {
        String sql = "INSERT INTO venta (cliente, productos, total, estado, fecha) VALUES (?, ?, ?, ?, NOW())";

        try (Connection conn = ConexionDB.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, venta.getCliente());
            ps.setString(2, venta.getProductos());
            ps.setDouble(3, venta.getTotal());
            ps.setString(4, venta.getEstado());

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
