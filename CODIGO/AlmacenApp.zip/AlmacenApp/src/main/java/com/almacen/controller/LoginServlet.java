/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.almacen.controller;

import com.almacen.dao.UsuarioDAO;
import com.almacen.model.Usuario;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;

public class LoginServlet extends HttpServlet {

    private UsuarioDAO usuarioDAO;

    @Override
    public void init() {
        usuarioDAO = new UsuarioDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtener parámetros del formulario de login
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Validar usuario en la base de datos
        Usuario usuario = usuarioDAO.validarUsuario(email, password);

        if (usuario != null) {
            // Guardar usuario en la sesión
            request.getSession().setAttribute("usuario", usuario);

            // Redirigir según el rol del usuario
            switch (usuario.getRolId()) {
                case 1: // Administrador
                    response.sendRedirect("views/Administrador/dashboard_admin.jsp");
                    break;
                case 2: // Vendedor
                    response.sendRedirect("views/Vendedor/registro_ventas.jsp"); 
                    break;
                case 3: // Almacén
                    response.sendRedirect("views/Almacen/gestion_inventario.jsp");
                    break;
                default:
                    response.sendRedirect("login.jsp?error=rol_no_definido");
                    break;
            }
        } else {
            // Si las credenciales no son correctas, redirigir al login con un error
            response.sendRedirect("login.jsp?error=credenciales_incorrectas");
        }
    }
}
