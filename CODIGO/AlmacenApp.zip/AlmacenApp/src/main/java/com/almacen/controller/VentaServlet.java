/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.almacen.controller;

import com.almacen.dao.VentaDAO;
import com.almacen.model.Venta;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;

public class VentaServlet extends HttpServlet {

    private VentaDAO ventaDAO;

    @Override
    public void init() {
        ventaDAO = new VentaDAO(); // Inicializamos el DAO para interactuar con la base de datos
    }

    // Método para registrar una nueva venta
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String cliente = request.getParameter("cliente");
        String productos = request.getParameter("productos");
        double total = Double.parseDouble(request.getParameter("total"));
        String estado = request.getParameter("estado");

        // Crear un nuevo objeto Venta
        Venta venta = new Venta();
        venta.setCliente(cliente);
        venta.setProductos(productos);
        venta.setTotal(total);
        venta.setEstado(estado);

        // Llamamos al DAO para agregar la venta
        ventaDAO.agregarVenta(venta);

        // Redirigir a la página de ventas
        response.sendRedirect("registro_ventas.jsp");
    }
}
