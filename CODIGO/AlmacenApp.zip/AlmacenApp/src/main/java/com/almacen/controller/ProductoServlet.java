/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.almacen.controller;

import com.almacen.dao.ProductoDAO;
import com.almacen.model.Producto;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

public class ProductoServlet extends HttpServlet {

    private ProductoDAO productoDAO;

    @Override
    public void init() {
        productoDAO = new ProductoDAO();  // Inicializamos el DAO para interactuar con la base de datos.
    }

    // Método para agregar un nuevo producto
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtener los datos del formulario
        String codigo = request.getParameter("codigo");
        String nombre = request.getParameter("nombre");
        String categoria = request.getParameter("categoria");
        int stock = Integer.parseInt(request.getParameter("stock"));
        double precio = Double.parseDouble(request.getParameter("precio"));
        String clasificacionABC = request.getParameter("clasificacionABC");

        // Crear un nuevo objeto Producto
        Producto producto = new Producto();
        producto.setCodigo(codigo);
        producto.setNombre(nombre);
        producto.setCategoria(categoria);
        producto.setStock(stock);
        producto.setPrecio(precio);
        producto.setClasificacionABC(clasificacionABC);

        // Llamar al DAO para agregar el producto
        productoDAO.agregarProducto(producto);

        // Redirigir al usuario al listado de productos
        response.sendRedirect("gestion_productos.jsp");
    }

    // Método para actualizar un producto
    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtener los datos del formulario
        String codigo = request.getParameter("codigo");
        String nombre = request.getParameter("nombre");
        String categoria = request.getParameter("categoria");
        int stock = Integer.parseInt(request.getParameter("stock"));
        double precio = Double.parseDouble(request.getParameter("precio"));
        String clasificacionABC = request.getParameter("clasificacionABC");

        // Crear un objeto Producto con los datos actualizados
        Producto producto = new Producto();
        producto.setCodigo(codigo);
        producto.setNombre(nombre);
        producto.setCategoria(categoria);
        producto.setStock(stock);
        producto.setPrecio(precio);
        producto.setClasificacionABC(clasificacionABC);

        // Llamar al DAO para actualizar el producto
        productoDAO.actualizarProducto(producto);

        // Redirigir a la página de productos
        response.sendRedirect("gestion_productos.jsp");
    }

    // Método para eliminar un producto
    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String codigo = request.getParameter("codigo");

        // Llamar al DAO para eliminar el producto
        productoDAO.eliminarProducto(codigo);

        // Redirigir a la página de productos
        response.sendRedirect("gestion_productos.jsp");
    }

    // Método para obtener todos los productos (este método puede usarse para cargar la tabla)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtener la lista de productos desde el DAO
        List<Producto> productos = productoDAO.obtenerProductos();

        // Colocar la lista de productos en el request para ser utilizada en el JSP
        request.setAttribute("productos", productos);

        // Despachar la solicitud al JSP para mostrar los productos
        RequestDispatcher dispatcher = request.getRequestDispatcher("gestion_productos.jsp");
        dispatcher.forward(request, response);
    }
}

